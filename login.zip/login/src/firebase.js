import firebase from 'firebase/app';
import 'firebase/auth';

var firebaseConfig = {
    apiKey: "AIzaSyAI-Q2FVGpff7hc4PSNwemmpCnsI12_Mww",
    authDomain: "login-a4772.firebaseapp.com",
    projectId: "login-a4772",
    storageBucket: "login-a4772.appspot.com",
    messagingSenderId: "111966931848",
    appId: "1:111966931848:web:592859ed64c2cd8003883d"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
export const auth = app.auth(); // Exporting auth separately if needed
export default app;
